const res={
    "no":[17],
    "maxnum":19,
    "hate":{2:3,
        6:2,
        16:2,
        23:3,
        13:3,
        29:4,
        39:8,
        42:8},
    "fun":{"enable":true,
           "range":[1,10],
           "group":{
                "3+13":{
                    "enable":true,
                    "key":3},
                "39+50":{
                    "enable":true,
                    "key":5},
                "1+23":{
                        "enable":true,
                        "key":1},
               
           }}
    }
    